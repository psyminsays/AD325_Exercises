package Week1.LinkedList;

public interface PersonInterface {
    void setName(String name);
    String getName();
}
