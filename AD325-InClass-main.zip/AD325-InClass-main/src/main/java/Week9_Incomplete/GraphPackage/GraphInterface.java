package Week9_Incomplete.GraphPackage;

public interface GraphInterface<T> extends BasicGraphInterface<T>,
        GraphAlgorithmsInterface<T>
{
} // end GraphInterface
